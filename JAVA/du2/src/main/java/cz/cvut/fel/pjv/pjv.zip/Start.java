/*
 * File name: Start.java
 * Date:      2014/09/04 12:34
 * Author:    Jan Faigl
 */

package cz.cvut.fel.pjv;

import java.io.IOException;

public class Start {

   public static void main(String[] args) throws IOException {
      Lab02 lab = new Lab02();
      lab.start(args);
   }
} 

/* end of Start.java */
