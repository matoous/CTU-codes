/*
  Created by dzivjmat on 31/03/2018.
 */

package student;

public class Constraint {
    public int count;
    public char color;

    Constraint(char key, int count) {
        this.color = key;
        this.count = count;
    }
}
