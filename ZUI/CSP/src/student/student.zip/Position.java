/*
  Created by dzivjmat on 31/03/2018.
 */

package student;

public class Position {
    public int x, y;

    Position(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
