package cz.cvut.fel.agents.pdv.student;

import java.util.*;

public class Log {
    private List<LogEntry> log;

    public Log(){
        this.log = new ArrayList<>();
    }

    public int size(){
        return this.log.size();
    }

    public void add(LogEntry x){
        this.log.add(x);
    }

    public LogEntry get(int idx){
        if(idx > size() || idx < 1) return null;
        return this.log.get(idx-1);
    }

    public int getTermOf(int idx){
        if(idx > size() || idx < 1) return 0;
        return this.log.get(idx-1).term;
    }

    public boolean contains(int idx){
        if(idx == 0) return false;
        return this.log.size() >= idx;
    }

    public int lastLogIndex(){
        return this.log.size();
    }

    public void cutTo(int idx){
        this.log = new ArrayList<>(log.subList(0, idx));
    }

    public void pop(){
        this.log.remove(this.log.size()-1);
    }

    public List<LogEntry> sub(int from, int to){
        return new ArrayList<>(this.log.subList(from, to));
    }

    public int lastLogTerm(){
        if(this.size() > 0){
            return this.get(this.size()).term;
        }
        return 0;
    }

    public Optional<Map<String, String>> lastEntry(){
        if(this.size() == 0){
            return Optional.empty();
        }
        Map<String, String> lastEntry = new HashMap<>();
        LogEntry e = this.log.get(this.lastLogIndex()-1);
        lastEntry.put(e.action.key, e.action.val);
        return Optional.of(lastEntry);
    }

    public Set<String> entryIds(){
        Set<String> ids = new HashSet<>();
        for(LogEntry e : this.log){
            ids.add(e.action.requestId);
        }
        return ids;
    }
}
