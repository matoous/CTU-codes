package cz.cvut.fel.agents.pdv.student;

import java.io.Serializable;

public class LogEntry implements Serializable {
    public final Integer term;
    public final Request action;

    public LogEntry(Integer term, Request req){
        this.term = term;
        this.action = req;
    }
}
