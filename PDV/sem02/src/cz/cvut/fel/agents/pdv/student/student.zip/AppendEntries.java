package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AppendEntries extends Message implements Serializable {
    public Integer term;

    public AppendEntries(Integer term, String leaderId, Integer prevLogIndex, Integer prevLogTerm, List<LogEntry> logEntries, Integer leaderCommit) {
        this.term = term;
        this.leaderId = leaderId;
        this.prevLogIndex = prevLogIndex;
        this.prevLogTerm = prevLogTerm;
        this.logEntries = logEntries;
        this.leaderCommit = leaderCommit;
    }

    public String leaderId;
    public Integer prevLogIndex;
    public Integer prevLogTerm;
    public List<LogEntry> logEntries;
    public Integer leaderCommit;

}

