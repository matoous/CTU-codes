package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

public class RequestVoteResponse extends Message {
    public RequestVoteResponse(Integer term, Boolean voteGranted) {
        this.term = term;
        this.voteGranted= voteGranted;
    }

    public Integer term;
    public Boolean voteGranted;
}
