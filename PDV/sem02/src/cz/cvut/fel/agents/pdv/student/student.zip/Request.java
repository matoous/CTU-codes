package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.evaluation.StoreOperationEnums;
import cz.cvut.fel.agents.pdv.raft.messages.IOperation;

import java.io.Serializable;

public class Request implements Serializable {
    public final String clientId;
    public final String requestId;
    public String op;
    public String key;
    public String val;

    public Request(String clientId, String requestId, IOperation op, String key, String val){
        this.clientId = clientId;
        this.requestId = requestId;
        this.op = op.toString();
        this.key = key;
        this.val = val;
    }
}
