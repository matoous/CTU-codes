package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

public class AppendEntriesResponse extends Message {
    public final Integer matchIndex;
    public Integer term;

    public AppendEntriesResponse(Integer term, Boolean success, Integer matchIndex) {
        this.term = term;
        this.success = success;
        this.matchIndex = matchIndex;
    }

    public Boolean success;

}